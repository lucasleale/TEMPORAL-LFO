
//#define TABLE_SIZE 4096